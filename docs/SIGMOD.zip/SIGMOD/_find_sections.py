from pathlib import Path
import re
src = Path(r"E:\CloudStation\MosaicOpt\docs\SIGMOD\paper.tex").read_text(encoding="utf-8")
sections = []
for m in re.finditer(r"\\section\{([^}]+)\}", src):
    sections.append((m.start(), m.group(1)))
print(f"Total sections: {len(sections)}")
for pos, name in sections:
    print(f"  {pos}: {name}")
print()
for m in re.finditer(r"begin\{thebibliography\}", src):
    print(f"  bib: {m.start()}")