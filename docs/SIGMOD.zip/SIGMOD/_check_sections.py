from pathlib import Path
import re
src = Path(r"E:\CloudStation\MosaicOpt\docs\SIGMOD\paper.tex").read_text(encoding="utf-8")
for m in re.finditer(r"\\section\{([^}]+)\}", src):
    print(f"  {m.group(1)}")
