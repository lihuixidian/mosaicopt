import re
from pathlib import Path
src = Path(r"E:\CloudStation\MosaicOpt\docs\SIGMOD\paper.tex").read_text(encoding="utf-8")
lines = src.split("\n")
markers = {
    "1_Intro": r"\section\{Introduction",
    "2_Background": r"\section\{Background",
    "3_Algebra": r"\section\{The Extended Algebra",
    "4_Equational": r"\section\{Equational Theory",
    "5_SQL": r"\section\{SQL Surface",
    "6_RBO": r"\section\{From Algebra to Optimizer",
    "7_CBO": r"\section\{Cost Model",
    "8_Experimental": r"\section\{Experimental Study",
    "Acks": r"\\begin\{acks\}",
    "References": r"\\begin\{thebibliography\}",
    "Appendix_A": r"\\section\{Prototype Implementation Details\}",
    "Appendix_B": r"\\section\{Proofs of Equational Identities\}",
}
for name, pat in markers.items():
    for i, ln in enumerate(lines, 1):
        if re.search(pat, ln):
            print(f"  {name}: line {i}")
            break
