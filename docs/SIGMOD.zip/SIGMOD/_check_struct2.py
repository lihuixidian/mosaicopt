from pathlib import Path
src = Path(r"E:\CloudStation\MosaicOpt\docs\SIGMOD\paper.tex").read_text(encoding="utf-8")
# Find Prototype and Proofs sections
i_a = src.find("Prototype Implementation Details")
i_b = src.find("Proofs of Equational")
i_c = src.find("Counterexamples for N1--N5")
i_d = src.find("SQL Desugaring Details")
i_e = src.find("Algorithm Pseudocode")
i_f = src.find("Discussion")
i_end = src.find("\\end{document}")
print(f"A: {i_a}, B: {i_b}, C: {i_c}, D: {i_d}, E: {i_e}, F: {i_f}, end: {i_end}")
for label, start, end in [("A", i_a, i_b), ("B", i_b, i_c), ("C", i_c, i_d), ("D", i_d, i_e), ("E", i_e, i_f), ("F", i_f, i_end)]:
    print(f"  §{label}: {end - start} bytes")
