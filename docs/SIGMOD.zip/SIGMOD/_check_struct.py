from pathlib import Path
import re
src = Path(r"E:\CloudStation\MosaicOpt\docs\SIGMOD\paper.tex").read_text(encoding="utf-8")
# Find all section-level commands
for m in re.finditer(r"\\(section|subsection|paragraph)\{([^}]+)\}", src):
    level = m.group(1)
    title = m.group(2)
    if level == "section":
        print(f"SECTION: {title}")
    elif level == "subsection":
        print(f"  SUB: {title}")
