from pathlib import Path
import re
src = Path(r"E:\CloudStation\MosaicOpt\docs\SIGMOD\paper.tex").read_text(encoding="utf-8")
markers = {}
for name, pat in [
    ("s8_exp_study", r"\\section\{Experimental Study"),
    ("A_proto", r"\\section\{Prototype Implementation Details"),
    ("B_proofs", r"\\section\{Proofs of Equational"),
    ("C_counterex", r"\\section\{Counterexamples for N1"),
    ("D_sql_desug", r"\\section\{SQL Desugaring Details"),
    ("E_alg", r"\\section\{Algorithm Pseudocode"),
    ("F_disc", r"\\section\{Discussion"),
    ("bib_start", r"\\begin\{thebibliography"),
    ("bib_end", r"\\end\{thebibliography"),
    ("end_doc", r"\\end\{document"),
]:
    m = re.search(pat, src)
    if m:
        markers[name] = m.start()
for name, pos in markers.items():
    print(f"  {name}: pos {pos}")